#!/bin/bash


# spack install command
spack "-d" "-v" "-k" "install" "--keep-stage" "--require-full-hash-match" "--no-check-signature" "--no-add" "-f" "/builds/scott/test-downstream/pipeline_scratch_dir/reproduction/zlib.yaml" || export SPACK_INSTALL_EXIT_ERROR=$?

spack -d ci rebuild --postprocess
