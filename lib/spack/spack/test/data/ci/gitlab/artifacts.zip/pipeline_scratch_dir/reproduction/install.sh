#!/bin/bash


# spack install command
"spack" "-d" "-v" "install" "--keep-stage" "--require-full-hash-match" "--no-check-signature" "--cdash-upload-url" "https://cdash.spack.io/submit.php?project=Spack+Testing" "--cdash-build" "pkgconf@1.7.4%gcc@7.5.0 arch=linux-ubuntu18.04-x86_64 (Reproducible Builds)" "--cdash-site" "Cloud Gitlab Infrastructure" "--cdash-buildstamp" "20210602-1515-Reproducible Builds" "--no-add" "-f" "/builds/scott/test-downstream/pipeline_scratch_dir/reproduction/pkgconf.yaml"
